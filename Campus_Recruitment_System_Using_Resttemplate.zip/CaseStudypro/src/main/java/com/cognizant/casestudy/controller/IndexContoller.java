package com.cognizant.casestudy.controller;

import java.io.IOException;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.cognizant.casestudy.dao.PlacementsRepository;
import com.cognizant.casestudy.dao.UsersDao;
import com.cognizant.casestudy.model.Placements;
import com.cognizant.casestudy.model.Users;


@Controller
public class IndexContoller {
	
	@Autowired
	UsersDao userDao;
	@Autowired
	HttpSession  session;
	@Autowired
	RestTemplate restTemplate;
	@Autowired
	PlacementsRepository placementsRepository;
	
	
	
	@GetMapping("/home")
	public String home() {
		return "home";
	}

	@GetMapping("/admin")
	public String admin() {
		
		return "admin";
	}
	
	@GetMapping("/coordinator")
	public String coordinator() {
		return "coordinator";
	}
//	@GetMapping("/placement")
//	public String placement() {
//		return "placement";
//	}
	@GetMapping("/student")
	public String student() {
		return "student";
	}

	
	@PostMapping("/coordinator_res")
	public String Login(@RequestParam String userid,@RequestParam String pwd) {
		Optional<Users> result=userDao.findByUsername(userid);
		if(result.isPresent()) {
				Users user =result.get();
//				if(!user.getPassword().equals(pwd)) 
				if(!user.getPassword().equals(pwd) || !user.getRole().equalsIgnoreCase("coordinator")){
					
					return "coordinator";
				}				
				else {
					session.setAttribute("userid", userid);
					//session.setAttribute("role", user.getRole());
					session.setAttribute("name", user.getUsername());
					return "coordinator_res";
				}
			}else {
				return "coordinator";
			}		
	}
//	@GetMapping("/addPlacement")
//	public String addPlacements(@ModelAttribute("placement") Placements placement,BindingResult result) {
//		return "addPlacements";	
//	}
	@GetMapping("/addplacementscoordinator")
	public String addPlacementsByCoordinator(@ModelAttribute("placement") Placements placement,BindingResult result) {
		return "addplacementscoordinator";
	}
	@PostMapping("/addplacementscoordinator")
	public String addPlacements(@RequestParam MultipartFile[] files, @RequestParam String name,
			  @RequestParam String dept, ModelMap modelMap) throws IOException{
		Users u=userDao.findById(1).get();
		Placements p=new Placements(name,dept,files[0].getInputStream().readAllBytes(),files[1].getInputStream().readAllBytes(),files[2].getInputStream().readAllBytes(),u);  
		ResponseEntity<String> s=restTemplate.postForEntity("http://localhost:8082/addPlacement", p, String.class);
		System.out.println(s);
		return "addplacementscoordinator";
	}
	
	
	
	
	// placements by coordinator
	
	
	
	@GetMapping(path = {"/placementsbycoordinator","/placementsbycoordinator/{pid}"})
	public String viewPlacements(@PathVariable(name="pid",required=false) Integer pid,ModelMap map){
		if(pid==null) {
			Placements[] s=restTemplate.getForObject("http://localhost:8082/viewPlacements", Placements[].class);
			map.addAttribute("placements",s);
			return "placementsbycoordinator";
		}
		else {
			Placements[] s=restTemplate.getForObject("http://localhost:8082/viewPlacements/"+pid, Placements[].class);
			String encoded = Base64.getEncoder().encodeToString(s[0].getImage());
			String encoded1 = Base64.getEncoder().encodeToString(s[0].getVedio());
			String file=new String(s[0].getFile());
			map.addAttribute("placements", s[0]);
			map.addAttribute("img",encoded);
			map.addAttribute("ved",encoded1);
			map.addAttribute("file", file);
			return "placement";
		}
	}
	
	@GetMapping(path={"/placementsbystudents","/placementsbystudents/{pid}"})
	public List<Placements> viewOtherPlacements(@PathVariable(name="pid",required=false) Integer pid){
		if(pid==null) {
			Placements[] s=restTemplate.getForObject("http://localhost:8082/viewOtherPlacements", Placements[].class);
			System.out.println(s);
			return null;
		}
		else {
			Placements[] s=restTemplate.getForObject("http://localhost:8082/viewOtherPlacements/"+pid, Placements[].class);
			System.out.println(s[0].getName());
			return null;
		}
	}
//	@GetMapping("/addplacementscoordinator")
//	public String addPlacementsByCoordinator() {
//		return "addplacementscoordinator";
//	}
//	@GetMapping("/coordinator_res")	
//	public String Login(@RequestParam String password) {
////		Optional<Users> result=dao.findByUsername(userid);
////		if(result.isPresent()) {
////				Users user =result.get();
////				if(user.getPassword().equals(password)) {
////					return "coordinator_res";
////				}				
////				else {
////					session.setAttribute("userid", userid);
////					session.setAttribute("role", user.getRole());
////					//session.setAttribute("name", user.getUsername());
////					return "redirect:/home";
////				}
//			
//				return password;
//			
//					
//	}
	
	
	
//	@GetMapping("/placementsbycoordinator")
//	public String placementsByCoordinator() {
//		return "placementsbycoordinator";
//	}
//	@GetMapping("/placementsbystudents")
//	public String placementsByStudents() {
//		return "placementsbystudents";
//	}

	
	
//	@GetMapping("/admin")
//	public ModelAndView login() {
//		ModelAndView mav = new ModelAndView("admin");
//		mav.addObject("user", new Users());
//		return mav;
//		
//	}
	/*
	 * @PostMapping("/admin") public String login(@ModelAttribute("user") Users
	 * user) { Users findByUsername =
	 * userService.findByUsername(user.getUsername());
	 * if(Objects.nonNull(findByUsername)) { return "redirect:/admin_res"; }else {
	 * 
	 * return "redirect:/admin"; }
	 * 
	 * }
	 */
	
	
	
	
	@GetMapping("/admin_res")
	public String admin_res() {
		
		return "admin_res";
	}
	
//	@PostMapping("/admin_res")
//	public String Admin_Login(@RequestParam String userid,@RequestParam String pwd) {
//		Optional<Users> result=userDao.findByUsername(userid);
//		if(result.isPresent()) {
//				Users user =result.get();
////				if(!user.getPassword().equals(pwd)) 
//				if(!user.getPassword().equals(pwd) || !user.getRole().equalsIgnoreCase("admin")){
//					
//					return "admin";
//				}				
//				else {
//					session.setAttribute("userid", userid);
//					//session.setAttribute("role", user.getRole());
//					session.setAttribute("name", user.getUsername());
//					return "admin_res";
//				}
//			}else {
//				return "admin";
//			}		
//	}
}
