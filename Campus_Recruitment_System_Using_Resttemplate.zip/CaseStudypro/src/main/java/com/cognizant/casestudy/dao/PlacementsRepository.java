package com.cognizant.casestudy.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.casestudy.model.Placements;
@Repository
public interface PlacementsRepository extends JpaRepository<Placements, Integer>{
	
	@Query("select p from Placements p where p.userid in (select u.id from Users u where u.role=?1)")
	List<Placements> findByRole(String role);
	@Query("select p from Placements p where p.id=?1 and p.userid in (select u.id from Users u where u.role=?2)")
	List<Placements> findByRoleById(int pid,String role);

}
