package com.cognizant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

@SpringBootApplication
public class CampusRecruitmentSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CampusRecruitmentSystemApplication.class, args);
	}

}
