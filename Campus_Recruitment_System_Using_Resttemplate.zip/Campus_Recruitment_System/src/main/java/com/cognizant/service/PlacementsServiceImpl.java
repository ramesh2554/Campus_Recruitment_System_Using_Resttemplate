package com.cognizant.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.PlacementsRepository;
import com.cognizant.model.Placements;
@Service
public class PlacementsServiceImpl implements PlacementsService {

	@Autowired
	private PlacementsRepository placementsdao;
	@Override
	public String addPlacements(Placements placement) {
			placementsdao.save(placement);
			return "Placements added Successfully";
		
	}

	@Override
	public List<Placements> viewPlacements() {
		
		return placementsdao.findByRole("coordinator");
	}

	@Override
	public List<Placements> viewOtherPlacements() {
		
		return placementsdao.findByRole("student");
	}

	@Override
	public List<Placements> viewPlacements(int pid) {
		return placementsdao.findByRoleById(pid,"coordinator");
		
	}

	@Override
	public List<Placements> viewOtherPlacements(int pid) {
		return placementsdao.findByRoleById(pid,"student");
	}

}
