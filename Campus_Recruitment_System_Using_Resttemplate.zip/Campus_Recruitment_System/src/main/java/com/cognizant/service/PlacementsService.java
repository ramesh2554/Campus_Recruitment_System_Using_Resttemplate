package com.cognizant.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cognizant.model.Placements;

@Service
public interface PlacementsService {

	String addPlacements(Placements placement);

	List<Placements> viewPlacements();

	List<Placements> viewOtherPlacements();

	List<Placements> viewPlacements(int pid);

	List<Placements> viewOtherPlacements(int pid);

	
}
