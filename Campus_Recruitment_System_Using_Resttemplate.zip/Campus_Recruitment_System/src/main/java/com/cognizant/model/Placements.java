package com.cognizant.model;

import java.io.File;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Placements {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@Column
	private String name;
	@Column
	private String dept;
	@Lob
	@Column
	private byte[] image;
	@Lob
	@Column
	private  byte[] file;
	@Lob
	@Column
	private byte[] vedio;
	@ManyToOne
	@JoinColumn
	private Users userid;
	public Placements(String name,String dept,byte[] image,byte[] file,byte[] vedio,Users u) {
		this.name=name;
		this.dept=dept;
		this.image=image;
		this.file=file;
		this.vedio=vedio;
		this.userid=u;
	}
}
